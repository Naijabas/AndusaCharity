 <footer class="main-footer">
        <strong>Copyright &copy; 2021 <a href="#">ANDUSA</a>.</strong>
        All rights reserved. Powerd bt
        <div class="float-right d-none d-sm-inline-block">
               <b>WEB</b> ANDUSA.ORG
        </div>
 </footer>
