<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
       <!-- Content Header (Page header) -->
       <section class="content-header">
              <div class="container-fluid">
                     <div class="mb-2 row">
                            <div class="col-sm-6">
                                   <h1>Blog Post and Events</h1>
                            </div>
                            <div class="col-sm-6">
                                   <ol class="breadcrumb float-sm-right">
                                          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                                          <li class="breadcrumb-item active">Blogs</li>
                                   </ol>
                            </div>
                     </div>
              </div><!-- /.container-fluid -->
       </section>

       <!-- Main content -->
       <section class="content">
              <div class="container-fluid">
                     <div class="row">
                            <div class="col-12">
                                   <div class="card">
                                          <div class="card-header">
                                                 <h3 class="card-title"><a href="<?php echo e(route('post')); ?>" class="btn btn-success">Create</a></h3>
                                          </div>
                                          <!-- /.card-header -->
                                          <div class="container">
                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alerts.success','data' => []]); ?>
<?php $component->withName('alerts.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                          </div>
                                          <div class="card-body">
                                                 <table id="example2" class="table table-bordered table-hover">
                                                        <thead>
                                                               <tr>
                                                                      <th>No..</th>
                                                                      <th>Image</th>
                                                                      <th>Title</th>
                                                                      <th>Date</th>
                                                                      <th>Action</th>
                                                               </tr>
                                                        </thead>
                                                        <tbody>
                                                               <?php
                                                               $i = 1;
                                                               ?>
                                                               <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                               <tr>
                                                                      <td><?php echo e($i++); ?></td>
                                                                      <td><img class="profile-user-img img-fluid img-circle"  src="<?php echo e(asset('storage/uploads/'.$post->banner_image)); ?>" alt="" width="20"></td>
                                                                      <td><?php echo e($post->title); ?></td>
                                                                      <td><?php echo e($post->created_at->diffForHumans()); ?></td>
                                                                      <td>
                                                                             <div class="btn-group">
                                                                                    <form action="<?php echo e(route('post-destroy', $post->id)); ?>" method="POST">
                                                                                           <?php echo csrf_field(); ?>
                                                                                           <?php echo e(method_field('DELETE')); ?>

                                                                                           <a class="btn btn-primary" title="Respond to post" href="<?php echo e(route('post-show', $post->id)); ?>"><i class="fa fa-eye"></i></a>
                                                                                           <button title="Delete post" onclick="return confirm('Are you sure you want to delete this...?')" class="btn btn-danger" href="#"><i class="fa fa-trash"></i></button>
                                                                                    </form>
                                                                             </div>
                                                                      </td>
                                                               </tr>
                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                        <tfoot>
                                                               <tr>
                                                                      <th>No..</th>
                                                                      <th>Image</th>
                                                                      <th>Title</th>
                                                                      <th>Date</th>
                                                                      <th>Action</th>
                                                               </tr>
                                                        </tfoot>
                                                 </table>
                                                 <?php echo e($posts->links()); ?>

                                          </div>
                                          <!-- /.card-body -->
                                   </div>
                                   <!-- /.card -->
                            </div>
                            <!-- /.col -->
                     </div>
                     <!-- /.row -->
              </div>
              <!-- /.container-fluid -->
       </section>
       <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andusa\AndusaCharity\resources\views/server/post/index.blade.php ENDPATH**/ ?>