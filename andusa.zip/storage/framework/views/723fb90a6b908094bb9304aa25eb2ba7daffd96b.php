<?php if(session()->has('success')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

  </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\andusa\AndusaCharity\resources\views/components/alerts/success.blade.php ENDPATH**/ ?>