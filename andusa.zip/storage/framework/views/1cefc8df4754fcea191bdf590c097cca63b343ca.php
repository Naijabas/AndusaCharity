<?php $__env->startSection('content'); ?><section id="inner-banner">
       <div class="overlay">
              <div class="container">
                     <div class="row">
                            <div class="col-sm-6">
                                   <h1>CONTACT US</h1>
                            </div>
                            <div class="col-sm-6">
                                   <h6 class="breadcrumb"><a href="<?php echo e(route('index')); ?>">Home</a> / Contact us</h6>
                            </div>
                     </div>
              </div>
       </div>
</section>

<div class="google-maps">
       <iframe src="https://maps.google.com/maps?q=1000 Duluth, Hwy lawrenceville%20of%20san%20Geogia&t=&z=13&ie=UTF8&iwloc=&output=embed" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<section id="about-sec">
       <div class="container">
              <div class="text-center row" style=" margin-top:-20px;">
                     <div class="col-md-4" style=" margin-top:20px;">
                            <div class="con-box">
                                   <div class="fancy-box-icon">
                                          <i class="fa fa-mobile-phone"></i>
                                   </div>
                                   <h3>PHONE</h3>
                                   <div class="fancy-box-content">
                                          <p>Phone 01: +1-347-751-9151<br>
                                                 Phone 02: +1-347-751-9151</p>
                                   </div>
                            </div>
                     </div>
                     <div class="col-md-4" style=" margin-top:20px;">
                            <div class="con-box" style="background:#2f3191;">
                                   <div class="fancy-box-icon">
                                          <i class="fa fa-map-marker"></i>
                                   </div>
                                   <h3>ADDRESS</h3>
                                   <div class="fancy-box-content">
                                          <p>1000 Duluth, Hwy lawrenceville<br>
                                                 Geogia </p>
                                   </div>
                            </div>
                     </div>
                     <div class="col-md-4" style=" margin-top:20px;">
                            <div class="con-box">
                                   <div class="fancy-box-icon">
                                          <i class="fa fa-envelope-o"></i>
                                   </div>
                                   <h3>EMAIL</h3>
                                   <div class="fancy-box-content">
                                    <a href="mailto:contactus@andusa.org"><p color ="white">contactus@andusa.org<br>
                                          </p></a>
                                          <p>contactus@andusa.org</p>
                                   </div>
                            </div>
                     </div>
                     <div class="clearfix"></div>
                     <h2>IF YOU GOT ANY QUESTIONS<br>
                            PLEASE DO NOT HESITATE TO SEND US A MESSAGE.</h2>
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alerts.success','data' => []]); ?>
<?php $component->withName('alerts.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                     <form class="clearfix con-form" method="post" action="<?php echo e(route('create-contact')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-4">
                                   <input type="text" name="name" size="40" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" aria-required="true" aria-invalid="false" placeholder="Your Name*">
                                   <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                   </span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                   <input type="email" name="email" size="40" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-required="true" aria-invalid="false" placeholder="Your Email*">
                                   <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                   </span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                   <input type="text" name="subject" size="40" class="<?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subject" aria-invalid="false" placeholder="Subject">
                                   <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                   </span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12">
                                   <textarea name="message" cols="40" rows="5" class="<?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" aria-invalid="false" placeholder="Message"></textarea>
                                   <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                   </span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-xs-12 submit-button">
                                   <input type="submit" value="send message" class="btn2" id="sub" style="border:none; margin: 20px 0 0 0">
                            </div>
                     </form>
              </div>
       </div>
</section>

<div class="callout">
       <div class="container">
              <div class="row">
                     <div class="col-md-6">
                            <h2>Change Their World. Change Yours. This changes everything.</h2><!-- /.callout-title -->
                     </div><!-- /.columns large-6 -->

                     <div class="col-md-6">
                            <div class="callout-actions">
                                   <a href="<?php echo e(route('contact')); ?>" class="button">Become Volunteer</a>

                                   <span class="callout-separator">
                                          <span>Or</span>
                                   </span>

                                   <a href="#" class="button">Donate For Cause</a>
                            </div><!-- /.callout-actions -->
                     </div><!-- /.columns large-6 -->
              </div><!-- /.row -->
       </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andusa\AndusaCharity\resources\views/contact.blade.php ENDPATH**/ ?>