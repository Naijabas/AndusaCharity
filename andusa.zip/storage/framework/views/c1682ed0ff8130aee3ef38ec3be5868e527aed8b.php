<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
       <!-- Content Header (Page header) -->
       <section class="content-header">
              <div class="container-fluid">
                     <div class="mb-2 row">
                            <div class="col-sm-6">
                                   <h1>Profile</h1>
                            </div>
                            <div class="col-sm-6">
                                   <ol class="breadcrumb float-sm-right">
                                          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                                          <li class="breadcrumb-item active">Trustee Profile</li>
                                   </ol>
                            </div>
                     </div>
              </div><!-- /.container-fluid -->
       </section>

       <!-- Main content -->
       <section class="content">
              <div class="container-fluid">
                     <div class="col-md-12">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alerts.success','data' => []]); ?>
<?php $component->withName('alerts.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                     </div>
                     <div class="row">
                            <div class="col-md-3">
                                   <!-- Profile Image -->
                                   <div class="card card-primary card-outline">
                                          <div class="card-body box-profile">
                                                 <div class="text-center">
                                                        <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('storage/uploads/'.$trustee->passport)); ?>" alt="Examiner image">
                                                 </div>

                                                 <h3 class="text-center profile-username"><?php echo e($trustee->name); ?></h3>

                                                 <p class="text-center text-muted"><?php echo e($trustee->occupation); ?></p>

                                                 <ul class="mb-3 list-group list-group-unbordered">
                                                        <li class="list-group-item">
                                                               <b>Email</b> <a class="float-right"><?php echo e($trustee->email); ?></a>
                                                        </li>
                                                        <li class="list-group-item">
                                                               <b>Phone</b> <a class="float-right"><?php echo e($trustee->phone); ?></a>
                                                        </li>
                                                        <li class="list-group-item">
                                                               <b>Date</b> <a class="float-right"><?php echo e($trustee->created_at->diffForHumans()); ?></a>
                                                        </li>
                                                        <li class="list-group-item">
                                                               <b>Address</b> <a class="float-right"><?php echo e($trustee->address); ?></a>
                                                        </li>
                                                 </ul>

                                                 <a href="#" class="btn btn-primary btn-block"><b>Contact</b></a>
                                          </div>
                                          <!-- /.card-body -->
                                   </div>
                                   <!-- /.card -->
                            </div>
                            <!-- /.col -->
                            <div class="col-md-9">
                                   <div class="card">
                                          <div class="p-2 card-header">
                                                 <ul class="nav nav-pills">
                                                        <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">Activity</a></li>
                                                        <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">Settings</a></li>
                                                 </ul>
                                          </div><!-- /.card-header -->
                                          <div class="card-body">
                                                 <div class="tab-content">
                                                        <div class="active tab-pane" id="activity">
                                                               <!-- Post -->
                                                               <div class="post">
                                                                      <div class="user-block">
                                                                             <img class="img-circle img-bordered-sm" src="<?php echo e(asset('storage/uploads/'.$trustee->passport)); ?>" alt="user image">
                                                                             <span class="username">
                                                                                    <a href="#"><?php echo e($trustee->name); ?></a>
                                                                                    <a href="#" class="float-right btn-tool"><i class="fas fa-times"></i></a>
                                                                             </span>
                                                                             <span class="description">Joinied- <?php echo e($trustee->created_at); ?></span>
                                                                      </div>
                                                                      <!-- /.user-block -->
                                                                      <p>
                                                                             <?php echo $trustee->bio; ?>

                                                                      </p>
                                                               </div>
                                                        </div>
                                                        <div class="tab-pane" id="settings">
                                                               <form class="form-horizontal" action="<?php echo e(route('trustee-update', $trustee->id)); ?>" method='post'>
                                                                      <?php echo csrf_field(); ?>
                                                                      <?php echo e(method_field('PATCH')); ?>

                                                                      <div class="form-group row">
                                                                             <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                                                                             <div class="col-sm-10">
                                                                                    <input type="text" name="name" value="<?php echo e($trustee->name); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter name">
                                                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span class="invalid-feedback" role="alert">
                                                                                           <strong><?php echo e($message); ?></strong>
                                                                                    </span>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                             </div>
                                                                      </div>
                                                                      <div class="form-group row">
                                                                             <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                                                                             <div class="col-sm-10">
                                                                                    <input type="email" name="email" value="<?php echo e($trustee->email); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter email address">
                                                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span class="invalid-feedback" role="alert">
                                                                                           <strong><?php echo e($message); ?></strong>
                                                                                    </span>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                             </div>
                                                                      </div>
                                                                      <div class="form-group row">
                                                                             <label for="inputName2" class="col-sm-2 col-form-label">Phone</label>
                                                                             <div class="col-sm-10">
                                                                                    <input type="test" name="phone" value="<?php echo e($trustee->phone); ?>" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter phone number">
                                                                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span class="invalid-feedback" role="alert">
                                                                                           <strong><?php echo e($message); ?></strong>
                                                                                    </span>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                             </div>
                                                                      </div>
                                                                      <div class="form-group row">
                                                                             <label for="inputName2" class="col-sm-2 col-form-label">Occupation</label>
                                                                             <div class="col-sm-10">
                                                                                    <input type="test" name="occupation" value="<?php echo e($trustee->occupation); ?>" class="form-control <?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter occupation">
                                                                                    <?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span class="invalid-feedback" role="alert">
                                                                                           <strong><?php echo e($message); ?></strong>
                                                                                    </span>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                             </div>
                                                                             <div class="form-group row">
                                                                                <label for="inputName2" class="col-sm-2 col-form-label">Post Held</label>
                                                                                <div class="col-sm-10">
                                                                                       <input type="test" name="post" value="<?php echo e($trustee->post); ?>" class="form-control <?php $__errorArgs = ['post'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter Post Held">
                                                                                       <?php $__errorArgs = ['post'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                       <span class="invalid-feedback" role="alert">
                                                                                              <strong><?php echo e($message); ?></strong>
                                                                                       </span>
                                                                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                      </div>
                                                                      <div class="form-group row">
                                                                             <label for="inputName2" class="col-sm-2 col-form-label">Address</label>
                                                                             <div class="col-sm-10">
                                                                                    <textarea name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter address"><?php echo e($trustee->address); ?></textarea>
                                                                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span class="invalid-feedback" role="alert">
                                                                                           <strong><?php echo e($message); ?></strong>
                                                                                    </span>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                             </div>
                                                                      </div>

                                                                      <div class="mb-3">
                                                                        <label for="passport">Passport</label>
                                                                        <div class="custom-file">
                                                                               <input type="file" class="custom-file-input <?php $__errorArgs = ['passport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="passport" name="passport" value="passport">
                                                                               <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                                               <?php $__errorArgs = ['passport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                               <span class="invalid-feedback" role="alert">
                                                                                      <strong><?php echo e($message); ?></strong>
                                                                               </span>
                                                                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>


                                                                      <div class="form-group row">
                                                                             <label for="inputName2" class="col-sm-2 col-form-label">Biography</label>
                                                                             <div class="col-sm-10">
                                                                                     <textarea name="bio" class="textarea <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter blog body" style="width: 100%; height: 400px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e($trustee->bio); ?></textarea>
                                                                                    <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                           <span class="invalid-feedback" role="alert">
                                                                                                  <strong><?php echo e($message); ?></strong>
                                                                                           </span>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                             </div>
                                                                      </div>
                                                                      <div class="form-group row">
                                                                             <div class="offset-sm-2 col-sm-10">
                                                                                    <button type="submit" class="btn btn-danger">Submit</button>
                                                                             </div>
                                                                      </div>
                                                               </form>
                                                        </div>
                                                        <!-- /.tab-pane -->
                                                 </div>
                                                 <!-- /.tab-content -->
                                          </div><!-- /.card-body -->
                                   </div>
                                   <!-- /.nav-tabs-custom -->
                            </div>
                            <!-- /.col -->
                     </div>
                     <!-- /.row -->
              </div><!-- /.container-fluid -->
       </section>
       <!-- /.content -->
</div>
<!-- /.content-wrapper -->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\andusa\AndusaCharity\resources\views/server/trustee/show.blade.php ENDPATH**/ ?>