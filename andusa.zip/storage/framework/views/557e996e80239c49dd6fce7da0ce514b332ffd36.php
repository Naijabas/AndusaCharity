<!DOCTYPE HTML>
<html class="no-js" lang="de">
<head>
       <meta charset="utf-8">
       <meta http-equiv="X-UA-Compatible" content="IE=edge">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <meta name="description" content="">
       <meta name="keywords" content="">
       <meta name="robots" content="index,follow">

       <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

       <title><?php echo e(config('app.name', 'ANDUSA')); ?></title>

       <link href="<?php echo e(asset('css/font-awesome.min.css')); ?> " rel="stylesheet">
       <link href="<?php echo e(asset('css/animate.css')); ?> " rel="stylesheet">
       <link href="<?php echo e(asset('css/bootsnav.css')); ?> " rel="stylesheet">
       <link href="<?php echo e(asset('css/bootstrap.css')); ?> " rel="stylesheet">
       <link href="<?php echo e(asset('css/style.css')); ?> " rel="stylesheet">
       <link rel="stylesheet" href="<?php echo e(asset('')); ?> css/swipebox.css">

       <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>
<body>
       <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.guest.nav','data' => []]); ?>
<?php $component->withName('partials.guest.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
       <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.guest.footer','data' => []]); ?>
<?php $component->withName('partials.guest.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

       <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?> "></script>
       <script src="<?php echo e(asset('js/bootstrap.js')); ?> "></script>
       <script src="<?php echo e(asset('js/bootsnav.js')); ?>"></script>
       <script src="<?php echo e(asset('js/banner.js')); ?> "></script>
       <script src="<?php echo e(asset('js/jquery.swipebox.js')); ?>"></script>
       <script type="text/javascript">
              $(document).ready(function() {
                     /* Basic Gallery */
                     $('.swipebox').swipebox();

                     /* Video */
                     $('.swipebox-video').swipebox();

                     /* Dynamic Gallery */
                     $('#gallery').click(function(e) {
                            e.preventDefault();
                            $.swipebox([{
                                          href: 'http://swipebox.csag.co/mages/image-1.jpg'
                                          , title: 'My Caption'
                                   }
                                   , {
                                          href: 'http://swipebox.csag.co/images/image-2.jpg'
                                          , title: 'My Second Caption'
                                   }
                            ]);
                     });

              });

       </script>
       <script src="js/script.js"></script>
              <div class="bwt-footer-copyright">
              <div class="container">
                     <div class="row">
                            <div class="col-md-6 copyright">
                                   <div class="left-text">Copyright &copy; ANDUSA Hope 2021. All Rights Reserved</div>
                            </div>
                            <div class="col-md-6">
                                   <div class="right-text">Design &amp; Developed for: <a href="https://www.andusa.org/" target="_blank"><strong>ANDUSA</strong> USA</a></div>
                            </div>
                     </div>
              </div>
       </div>
</footer>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\andusa\AndusaCharity\resources\views/layouts/guest.blade.php ENDPATH**/ ?>